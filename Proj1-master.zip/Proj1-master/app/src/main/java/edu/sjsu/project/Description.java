package edu.sjsu.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Description extends AppCompatActivity {
    String TourName;
    TextView text;

    String[] tour1Description = {"Randdom", "Rating: 5/5", "Details"};

    Desc[] listOfTours;
    Desc temp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);
        text = findViewById(R.id.textView22);
        Bundle mBundle = getIntent().getExtras();
        if(mBundle != null){
            TourName = mBundle.getString("TourName");
        }

        if(TourName.equals("Randdom"))
        {
            TourName = tour1Description[0] + ", " + tour1Description[1] + ", " + tour1Description[2];
        }


        /*
        Desc d1 = new Desc("Randdom", "Rating 5/5", "Details");
        listOfTours[0] = d1;
        for(int i = 0; i<=listOfTours.length;i++)
        {
            if(listOfTours[i].getName().equals(TourName))
            {
                temp = listOfTours[i];
            }
        }
        TourName = temp.getName() + ", " + temp.getRating() + ", " +temp.getDetails();
         */

        text.setText(TourName);
    }
}

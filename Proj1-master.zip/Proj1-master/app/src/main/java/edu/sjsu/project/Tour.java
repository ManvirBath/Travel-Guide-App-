package edu.sjsu.project;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.Toast;

public class Tour extends TabActivity implements TabHost.OnTabChangeListener {

    ImageView mImageView;
    City[] ListOfCity;
    City temp;

    String[] CITY_SEE;
    String[] CITY_DINE;
    String[] CITY_SHOP;
    String[] CITY_STAY;
    int[] Image_SEE;
    int[] Image_DINE;
    int[] Image_SHOP;
    int[] Image_STAY;
    // List of Tours for city1 and images
    String[] CITY1_SEE = {"Randdom"};
    String[] CITY1_DINE = {"Randdom"};
    String[] CITY1_SHOP = {"Randdom"};
    String[] CITY1_STAY = {"Randdom"};
    int[] CITY1_Image_SEE = {R.drawable.flag_australia};
    int[] CITY1_Image_DINE = {R.drawable.flag_australia};
    int[] CITY1_Image_SHOP = {R.drawable.flag_australia};
    int[] CITY1_Image_STAY = {R.drawable.flag_australia};

    // make variables for all the cities like above

    int res;
    ListView mListView;
    ListView mListView2;
    ListView mListView3;
    ListView mListView4;
    MyAdapter mAdapter;
    MyAdapter mAdapter1;
    MyAdapter mAdapter2;
    MyAdapter mAdapter3;

    private TabHost tabHost;
    private static final String LIST1_TAB_TAG = "SEE & DO";
    private static final String LIST2_TAB_TAG = "DINE";
    private static final String LIST3_TAB_TAG = "SHOP";
    private static final String LIST4_TAB_TAG = "STAY";
    String cityName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        //City Brisbane = new City("Brisbane", new String[]{"RandomSEE"},new String[]{"RandomDINE"},new String[]{"RandomSHOP"}, new String[]{"RandomSTAY"}, new int[]{R.drawable.flag_australia});
        //ListOfCity[0] = Brisbane;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour);
        tabHost = getTabHost();
        tabHost.setOnTabChangedListener(this);
        mListView = findViewById(R.id.listview4);
        mListView2 = findViewById(R.id.listview5);
        mListView3 = findViewById(R.id.listview6);
        mListView4 = findViewById(R.id.listview7);
        Bundle mBundle = getIntent().getExtras();
        if(mBundle != null){
            cityName = mBundle.getString("CityName");
        }

        if(cityName.equals("Brisbane"))
        {
            CITY_SEE = CITY1_SEE;
            CITY_DINE = CITY1_DINE;
            CITY_SHOP = CITY1_SHOP;
            CITY_STAY = CITY1_STAY;
            Image_SEE = CITY1_Image_SEE;
            Image_DINE = CITY1_Image_DINE;
            Image_SHOP = CITY1_Image_SHOP;
            Image_STAY = CITY1_Image_STAY;
        }



        mAdapter = new MyAdapter(Tour.this, CITY_SEE, Image_SEE);
        mAdapter1 = new MyAdapter(Tour.this, CITY_DINE, Image_DINE);
        mAdapter2 = new MyAdapter(Tour.this, CITY_SHOP, Image_SHOP);
        mAdapter3 = new MyAdapter(Tour.this, CITY_STAY, Image_STAY);
        mListView.setAdapter(mAdapter);
        mListView2.setAdapter(mAdapter1);
        mListView3.setAdapter(mAdapter2);
        mListView4.setAdapter(mAdapter3);


        /*

        for(int i =0; i<=ListOfCity.length;i++)
        {
            if(ListOfCity[i].getName().equals(cityName))
            {
                temp = ListOfCity[i];
            }
        }

        mAdapter = new MyAdapter(Tour.this, temp.getSEE(), temp.getImage());
        mAdapter1 = new MyAdapter(Tour.this, temp.getDINE(), temp.getImage());
        mAdapter2 = new MyAdapter(Tour.this, temp.getSHOP(), temp.getImage());
        mAdapter3 = new MyAdapter(Tour.this, temp.getSTAY(), temp.getImage());
        CITY_SEE = temp.getSEE();
        CITY_DINE = temp.getDINE();
        CITY_SHOP = temp.getSHOP();
        CITY_STAY = temp.getSTAY();

        mListView.setAdapter(mAdapter);
        mListView2.setAdapter(mAdapter1);
        mListView3.setAdapter(mAdapter2);
        mListView4.setAdapter(mAdapter3);
         */


        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(Tour.this, Description.class);
                mIntent.putExtra("TourName", CITY_SEE[i]);
                startActivity(mIntent);
            }
        });

        mListView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(Tour.this, Description.class);
                mIntent.putExtra("TourName", CITY_DINE[i]);
                startActivity(mIntent);
            }
        });

        mListView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(Tour.this, Description.class);
                mIntent.putExtra("TourName", CITY_SHOP[i]);
                startActivity(mIntent);
            }
        });

        mListView4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(Tour.this, Description.class);
                mIntent.putExtra("TourName", CITY_STAY[i]);
                startActivity(mIntent);
            }
        });

        tabHost.addTab(tabHost.newTabSpec(LIST1_TAB_TAG).setIndicator(LIST1_TAB_TAG).setContent(new TabHost.TabContentFactory() {
            public View createTabContent(String arg0) {
                return mListView;
            }
        }));
        tabHost.addTab(tabHost.newTabSpec(LIST2_TAB_TAG).setIndicator(LIST2_TAB_TAG).setContent(new TabHost.TabContentFactory() {
            public View createTabContent(String arg0) {
                return mListView2;
            }
        }));
        tabHost.addTab(tabHost.newTabSpec(LIST3_TAB_TAG).setIndicator(LIST3_TAB_TAG).setContent(new TabHost.TabContentFactory() {
            public View createTabContent(String arg0) {
                return mListView3;
            }
        }));
        tabHost.addTab(tabHost.newTabSpec(LIST4_TAB_TAG).setIndicator(LIST4_TAB_TAG).setContent(new TabHost.TabContentFactory() {
            public View createTabContent(String arg0) {
                return mListView4;
            }
        }));

    }

    @Override
    public void onTabChanged(String tabId) {

    }
}
